package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import java.util.ArrayList


class MainActivity : AppCompatActivity() {

    lateinit var opcao: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



            opcao = findViewById(R.id.sp_filtroChecklist) as Spinner

            var filtrosChecklist = arrayOf("Nenhum","Ascendente", "Descendente", "Importância")

            opcao.adapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, filtrosChecklist)


            opcao.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                }


            }


}
            private fun gerarList(size: Int): List<ItemChecklist>{

                val list = ArrayList<ItemChecklist>()

                    val item = ItemChecklist("")
                    list+= item
                    return list
    }

        }
