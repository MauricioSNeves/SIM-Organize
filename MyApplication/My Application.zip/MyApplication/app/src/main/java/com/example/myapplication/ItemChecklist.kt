package com.example.myapplication

import android.widget.ImageButton

data class ItemChecklist ( val nomeTarefa: String)